import type React from "react"
import "@/app/globals.css"
import { Inter, Caveat } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import Header from "@/components/header"
import SpaceBackground from "@/components/space-background"
import { cn } from "@/lib/utils"
import Script from "next/script"
// Add the import for EmailJSInit
import EmailJSInit from "@/components/emailjs-init"

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" })
const caveat = Caveat({ subsets: ["latin"], variable: "--font-handwriting" })

export const metadata = {
  title: "Chinmay Deshpande | Portfolio",
  description: "Product-Focused Data Analyst & Engineer",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <Script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js" />
      </head>
      <body className={cn("min-h-screen bg-background font-sans antialiased", inter.variable, caveat.variable)}>
        {/* Add the EmailJSInit component inside the ThemeProvider */}
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <EmailJSInit />
          <SpaceBackground />
          <Header className="absolute top-0 left-0 right-0 z-50 bg-transparent" />
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'