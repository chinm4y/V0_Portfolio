"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Projects", href: "#projects" },
    { name: "Contact", href: "#contact" },
  ]

  const menuVariants = {
    closed: {
      opacity: 0,
      y: -20,
      transition: {
        duration: 0.2,
        ease: "easeInOut",
      },
    },
    open: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.3,
        ease: "easeOut",
        staggerChildren: 0.1,
        delayChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    closed: { opacity: 0, y: -10 },
    open: { opacity: 1, y: 0 },
  }

  return (
    <>
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-50 px-6 md:px-12 py-6 flex items-center justify-between transition-all duration-300",
          isScrolled ? "bg-black/80 backdrop-blur-md" : "bg-transparent",
        )}
      >
        <Link href="/" className="text-lg font-medium tracking-tight">
          Chinmay Deshpande
        </Link>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex flex-col items-center justify-center w-10 h-10 relative z-50"
          aria-label={isOpen ? "Close menu" : "Open menu"}
        >
          <span
            className={cn(
              "w-6 h-0.5 bg-white transition-all duration-300 ease-out",
              isOpen ? "rotate-45 translate-y-0.5" : "-translate-y-1",
            )}
          />
          <span
            className={cn(
              "w-6 h-0.5 bg-white transition-all duration-300 ease-out",
              isOpen ? "-rotate-45" : "translate-y-1",
            )}
          />
        </button>
      </header>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial="closed"
            animate="open"
            exit="closed"
            variants={menuVariants}
            className="fixed inset-0 z-40 bg-black flex items-center justify-center"
          >
            <nav className="flex flex-col items-center justify-center space-y-8">
              {navItems.map((item) => (
                <motion.div key={item.name} variants={itemVariants}>
                  <Link
                    href={item.href}
                    className="text-5xl font-light hover:text-gray-300 transition-colors py-2 px-4"
                    onClick={() => setIsOpen(false)}
                  >
                    {item.name}
                  </Link>
                </motion.div>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
