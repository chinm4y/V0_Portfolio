"use client"

import type React from "react"

import { useRef, useState, type FormEvent } from "react"
import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { Mail, Linkedin, Github, ArrowUpRight, CheckCircle, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import emailjs from "@emailjs/browser"

interface FormData {
  name: string
  email: string
  message: string
}

export default function Contact() {
  const ref = useRef(null)
  const formRef = useRef<HTMLFormElement>(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setSubmitStatus("idle")

    // EmailJS configuration
    const serviceID = "service_nlmn3li" // Your EmailJS service ID
    const templateID = "template_d8gjf3f" // Your EmailJS template ID
    const publicKey = "cuHZjaw6uINtQ3SPV" // Your EmailJS public key

    // Prepare template parameters
    const templateParams = {
      to_email: "deshpande.chi@northeastern.edu",
      from_name: formData.name,
      from_email: formData.email,
      message: formData.message,
    }

    try {
      // Send email using EmailJS
      await emailjs.send(serviceID, templateID, templateParams, publicKey)

      // Success case
      setSubmitStatus("success")
      setFormData({ name: "", email: "", message: "" })

      // Reset success message after 5 seconds
      setTimeout(() => {
        setSubmitStatus("idle")
      }, 5000)
    } catch (error) {
      // Error case
      setSubmitStatus("error")
      setErrorMessage("There was an error sending your message. Please try again or email directly.")

      // Reset error message after 5 seconds
      setTimeout(() => {
        setSubmitStatus("idle")
        setErrorMessage("")
      }, 5000)
    } finally {
      setIsSubmitting(false)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  const contactLinks = [
    {
      name: "Email",
      value: "deshpande.chi@northeastern.edu",
      href: "mailto:deshpande.chi@northeastern.edu",
      icon: <Mail className="h-5 w-5" />,
    },
    {
      name: "LinkedIn",
      value: "linkedin.com/in/chinmaymd",
      href: "https://www.linkedin.com/in/chinmaymd/",
      icon: <Linkedin className="h-5 w-5" />,
    },
    {
      name: "GitHub",
      value: "github.com/chinm4y",
      href: "https://github.com/chinm4y",
      icon: <Github className="h-5 w-5" />,
    },
  ]

  return (
    <section id="contact" className="py-24 md:py-32 px-6 md:px-12 border-t border-blue-900/30" ref={ref}>
      <motion.div
        className="max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-16 tracking-tight text-white">
          Contact
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            variants={itemVariants}
            className="bg-[rgba(20,20,40,0.7)] backdrop-blur-sm p-8 rounded-lg border border-blue-900/50 shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
          >
            <h3 className="text-xl font-semibold mb-6 text-blue-200">Get in touch</h3>
            <p className="text-blue-300 mb-8">
              Interested in working together or have a question? Feel free to reach out through any of these channels or
              use the contact form.
            </p>

            <div className="space-y-6">
              {contactLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="flex items-center group hover:text-blue-200 transition-colors"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <div className="w-10 h-10 rounded-full bg-blue-900/30 flex items-center justify-center mr-4 text-blue-400">
                    {link.icon}
                  </div>
                  <div className="flex-grow">
                    <span className="block text-sm text-blue-400">{link.name}</span>
                    <span className="text-blue-300 group-hover:text-blue-200 transition-colors">{link.value}</span>
                  </div>
                  <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity text-blue-400" />
                </a>
              ))}
            </div>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Card className="border border-blue-900/50 bg-[rgba(20,20,40,0.7)] backdrop-blur-sm shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
              <CardContent className="p-6">
                {submitStatus === "success" && (
                  <Alert className="mb-6 bg-green-900/50 text-green-200 border-green-700/50">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    <AlertDescription>Your message has been sent successfully!</AlertDescription>
                  </Alert>
                )}

                {submitStatus === "error" && (
                  <Alert className="mb-6 bg-red-900/50 text-red-200 border-red-700/50">
                    <AlertCircle className="h-4 w-4 mr-2" />
                    <AlertDescription>{errorMessage}</AlertDescription>
                  </Alert>
                )}

                <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-blue-300">
                      Name
                    </label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Your name"
                      className="border-blue-900/50 focus:border-blue-700 bg-blue-900/20 text-white"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-blue-300">
                      Email
                    </label>
                    <Input
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      type="email"
                      placeholder="Your email"
                      className="border-blue-900/50 focus:border-blue-700 bg-blue-900/20 text-white"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium text-blue-300">
                      Message
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Your message"
                      rows={5}
                      className="border-blue-900/50 focus:border-blue-700 bg-blue-900/20 text-white"
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-blue-600 text-white hover:bg-blue-700 shadow-[0_0_15px_rgba(37,99,235,0.3)]"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </section>
  )
}
