"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

export default function Hero() {
  const [currentGreetingIndex, setCurrentGreetingIndex] = useState(0)
  const [showName, setShowName] = useState(false)
  const [showSummary, setShowSummary] = useState(false)
  const [showButton, setShowButton] = useState(false)
  const [transitionComplete, setTransitionComplete] = useState(false)

  // Typewriter animation states
  const [displayText, setDisplayText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)
  const [loopNum, setLoopNum] = useState(0)
  const [typingSpeed, setTypingSpeed] = useState(150)

  const greetings = ["Hello", "Hola", "Bonjour", "Ciao", "Namaste", "Hej", "Hallo", "Olá", "Salut", "Konnichiwa"]
  const typewriterTexts = [
    "data enthusiast",
    "engineer",
    "data analyst",
    "soccer player",
    "creative thinker",
    "lifelong learner",
  ]

  useEffect(() => {
    // Handle greeting animation sequence - complete all greetings in ~2 seconds
    if (currentGreetingIndex < greetings.length) {
      const timer = setTimeout(() => {
        setCurrentGreetingIndex(currentGreetingIndex + 1)
      }, 200) // 200ms per greeting = ~2 seconds total for 10 greetings

      return () => clearTimeout(timer)
    } else if (!showName) {
      // Show name after greetings finish
      setShowName(true)

      // Set transition complete after animation duration
      const transitionTimer = setTimeout(() => {
        setTransitionComplete(true)
        // Show summary right after name animation completes
        setShowSummary(true)
      }, 1000)

      // Show button after summary appears
      const buttonTimer = setTimeout(() => {
        setShowButton(true)
      }, 1800)

      return () => {
        clearTimeout(transitionTimer)
        clearTimeout(buttonTimer)
      }
    }
  }, [currentGreetingIndex, greetings.length, showName])

  // Typewriter effect
  useEffect(() => {
    if (!showSummary) return

    const currentText = typewriterTexts[loopNum % typewriterTexts.length]
    const fullText = "I'm a " + currentText

    // Set typing speed based on whether we're typing or deleting
    const updatedSpeed = isDeleting ? 80 : 150

    // Handle typing and deleting logic
    const timer = setTimeout(() => {
      if (!isDeleting) {
        // Typing forward
        setDisplayText(fullText.substring(0, displayText.length + 1))

        // If we've typed the full text, start deleting after a pause
        if (displayText === fullText) {
          setIsDeleting(true)
          setTypingSpeed(1000) // Pause before deleting
        }
      } else {
        // Deleting
        setDisplayText(fullText.substring(0, displayText.length - 1))

        // If we've deleted everything, move to the next word
        if (displayText === "I'm a ") {
          setIsDeleting(false)
          setLoopNum(loopNum + 1)
        }
      }
    }, typingSpeed)

    return () => clearTimeout(timer)
  }, [displayText, isDeleting, loopNum, showSummary, typingSpeed, typewriterTexts])

  // Initialize typewriter when summary shows
  useEffect(() => {
    if (showSummary) {
      setDisplayText("I'm a ")
    }
  }, [showSummary])

  const scrollToProjects = () => {
    const projectsSection = document.getElementById("projects")
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="home" className="relative flex flex-col items-center justify-center min-h-screen overflow-hidden">
      {/* Background that transitions from dark to transparent */}
      <motion.div
        className="absolute inset-0 z-0"
        initial={{ backgroundColor: "rgba(10, 10, 30, 0.8)" }}
        animate={{
          backgroundColor: showName ? "rgba(10, 10, 30, 0)" : "rgba(10, 10, 30, 0.8)",
        }}
        transition={{ duration: 1, ease: "easeInOut" }}
      />

      <div className="max-w-5xl mx-auto text-center z-10 px-6">
        <div className="h-32 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {currentGreetingIndex < greetings.length && (
              <motion.h2
                key={currentGreetingIndex}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.1 }}
                className="text-5xl md:text-6xl lg:text-7xl font-handwriting text-white"
              >
                {greetings[currentGreetingIndex]}
              </motion.h2>
            )}

            {showName && (
              <div className="flex flex-col md:flex-row items-center justify-center md:justify-start gap-6 md:gap-8">
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{
                    type: "spring",
                    stiffness: 100,
                    damping: 15,
                    duration: 0.8,
                  }}
                  className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-indigo-300 shadow-[0_0_15px_rgba(147,112,219,0.5)]"
                >
                  <Image
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-04-09%20at%205.46.23%20PM-r4ZZlzXMgcsdvBS6IhJ9gqIUoNTaYe.jpeg"
                    alt="Chinmay Deshpande"
                    fill
                    className="object-cover"
                  />
                </motion.div>

                <div className="flex flex-col items-center md:items-start">
                  <motion.h1
                    initial={{ opacity: 0, y: 100 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      type: "spring",
                      stiffness: 50,
                      damping: 15,
                      duration: 1,
                    }}
                    className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tighter text-center md:text-left text-white"
                  >
                    Chinmay Deshpande
                  </motion.h1>

                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                    className="text-lg md:text-xl text-indigo-300 mt-2"
                  >
                    Product focused Data Enthusiast
                  </motion.p>
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>

        <AnimatePresence>
          {showSummary && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="mt-8 md:mt-6 h-8"
            >
              <p className="text-xl md:text-2xl font-mono text-indigo-200 inline-block">
                {displayText}
                <span className="animate-blink">|</span>
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showSummary && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="text-lg md:text-xl mt-4 text-indigo-200 max-w-3xl mx-auto font-normal"
            >
              Product-Focused Data Analyst & Engineer | Turning real-world data into meaningful insight and impact
            </motion.p>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showButton && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="mt-12"
            >
              <Button
                onClick={scrollToProjects}
                size="lg"
                className="bg-indigo-600 text-white hover:bg-indigo-700 transition-colors shadow-[0_0_15px_rgba(99,102,241,0.4)]"
              >
                View My Work
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  )
}
