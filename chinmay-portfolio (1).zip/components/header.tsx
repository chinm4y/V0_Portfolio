"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"

export default function Header({ className }: { className?: string }) {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [greetingsPhase, setGreetingsPhase] = useState(true)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)

    // Check if we're past the greetings phase after 2.5 seconds
    const timer = setTimeout(() => {
      setGreetingsPhase(false)
    }, 2500)

    return () => {
      window.removeEventListener("scroll", handleScroll)
      clearTimeout(timer)
    }
  }, [])

  const navItems = [
    { name: "Home", href: "#home" },
    { name: "About", href: "#about" },
    { name: "Education", href: "#education" },
    { name: "Experience", href: "#experience" },
    { name: "Projects", href: "#projects" },
    { name: "Contact", href: "#contact" },
  ]

  const handleNavClick = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    if (mobileMenuOpen) {
      setMobileMenuOpen(false)
    }
  }

  return (
    <>
      <header
        className={cn(
          "fixed top-0 w-full z-50 transition-all duration-300 px-6 md:px-12 py-4 flex items-center justify-between",
          isScrolled
            ? "bg-[rgba(10,10,30,0.8)] backdrop-blur-md shadow-[0_4px_30px_rgba(0,0,0,0.1)]"
            : "bg-transparent",
          className,
        )}
      >
        <Link href="/" className="text-xl font-bold tracking-tighter transition-colors duration-500 text-white">
          CD
        </Link>

        <div className="hidden md:flex items-center space-x-8 transition-colors duration-500 text-white">
          <nav className="flex items-center space-x-6">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => handleNavClick(item.href)}
                className="text-sm font-medium transition-colors text-white/80 hover:text-white cursor-pointer"
              >
                {item.name}
              </button>
            ))}
          </nav>
        </div>

        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden flex flex-col items-center justify-center w-10 h-10 relative z-50 transition-colors duration-500 text-white"
          aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
        >
          <span
            className={cn(
              "w-6 h-0.5 bg-white transition-all duration-300 ease-out",
              mobileMenuOpen ? "rotate-45 translate-y-0.5" : "-translate-y-1",
            )}
          />
          <span
            className={cn(
              "w-6 h-0.5 bg-white transition-all duration-300 ease-out",
              mobileMenuOpen ? "-rotate-45" : "translate-y-1",
            )}
          />
        </button>
      </header>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-[rgba(10,10,30,0.95)] flex items-center justify-center"
          >
            <nav className="flex flex-col items-center justify-center space-y-8 p-8">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleNavClick(item.href)}
                  className="text-2xl font-medium text-white hover:text-indigo-300 transition-colors cursor-pointer"
                >
                  {item.name}
                </button>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
