"use client"

import { useEffect, useRef } from "react"

export default function TechBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions to match window size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      drawBackground()
    }

    window.addEventListener("resize", resizeCanvas)
    resizeCanvas()

    // Draw the tech background
    function drawBackground() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Set a very light purple color with low opacity
      ctx.strokeStyle = "rgba(147, 112, 219, 0.1)"
      ctx.lineWidth = 1

      // Draw circuit-like patterns
      drawCircuitPattern()

      // Draw some data points
      drawDataPoints()
    }

    function drawCircuitPattern() {
      const gridSize = 50
      const offset = 10

      // Draw horizontal lines
      for (let y = offset; y < canvas.height; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)

        let x = 0
        while (x < canvas.width) {
          const lineLength = Math.random() * 100 + 50
          x += lineLength

          if (x < canvas.width) {
            ctx.lineTo(x, y)

            // Randomly add vertical connections
            if (Math.random() > 0.7) {
              const vertLength = Math.random() * 30 + 20
              const direction = Math.random() > 0.5 ? 1 : -1

              ctx.moveTo(x, y)
              ctx.lineTo(x, y + vertLength * direction)
              ctx.moveTo(x, y)
            }

            // Add a small gap
            x += 10
            ctx.moveTo(x, y)
          }
        }

        ctx.stroke()
      }

      // Draw vertical lines
      for (let x = offset; x < canvas.width; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)

        let y = 0
        while (y < canvas.height) {
          const lineLength = Math.random() * 100 + 50
          y += lineLength

          if (y < canvas.height) {
            ctx.lineTo(x, y)

            // Randomly add horizontal connections
            if (Math.random() > 0.7) {
              const horizLength = Math.random() * 30 + 20
              const direction = Math.random() > 0.5 ? 1 : -1

              ctx.moveTo(x, y)
              ctx.lineTo(x + horizLength * direction, y)
              ctx.moveTo(x, y)
            }

            // Add a small gap
            y += 10
            ctx.moveTo(x, y)
          }
        }

        ctx.stroke()
      }
    }

    function drawDataPoints() {
      // Draw some nodes/data points
      ctx.fillStyle = "rgba(147, 112, 219, 0.08)"

      for (let i = 0; i < 50; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        const radius = Math.random() * 5 + 2

        ctx.beginPath()
        ctx.arc(x, y, radius, 0, Math.PI * 2)
        ctx.fill()

        // Occasionally draw connecting lines between points
        if (Math.random() > 0.7) {
          const x2 = x + (Math.random() * 100 - 50)
          const y2 = y + (Math.random() * 100 - 50)

          ctx.beginPath()
          ctx.moveTo(x, y)
          ctx.lineTo(x2, y2)
          ctx.stroke()
        }
      }
    }

    return () => {
      window.removeEventListener("resize", resizeCanvas)
    }
  }, [])

  return (
    <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-30" style={{ filter: "blur(1px)" }} />
  )
}
