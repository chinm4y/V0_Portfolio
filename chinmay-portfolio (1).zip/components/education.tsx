"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { Award, Calendar } from "lucide-react"

interface EducationEntry {
  institution: string
  location: string
  degree: string
  period: string
  gpa: string
  logo: string
}

export default function Education() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const educationEntries: EducationEntry[] = [
    {
      institution: "Northeastern University",
      location: "Boston",
      degree: "Master of Science in Computer Software Engineering",
      period: "Aug 2023 – Aug 2025",
      gpa: "GPA 3.8",
      logo: "/placeholder.svg?height=80&width=80",
    },
    {
      institution: "Pune University",
      location: "India",
      degree: "Bachelor of Engineering in Computers, Honors in Data Science",
      period: "Aug 2018 – Jul 2022",
      gpa: "GPA 3.7",
      logo: "/placeholder.svg?height=80&width=80",
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  // Create geometric icons for education
  const createEducationIcon = (index: number) => {
    const colors = [
      ["#8B5CF6", "#C4B5FD"], // violet
      ["#6366F1", "#A5B4FC"], // indigo
    ]

    const colorPair = colors[index % colors.length]

    return (
      <div className="w-16 h-16 flex items-center justify-center">
        <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
          {index % 2 === 0 ? (
            // First icon - hexagon with inner elements
            <>
              <polygon
                points="20,4 34,12 34,28 20,36 6,28 6,12"
                fill={colorPair[1]}
                stroke={colorPair[0]}
                strokeWidth="1"
              />
              <circle cx="20" cy="20" r="8" fill={colorPair[0]} />
              <circle cx="20" cy="20" r="4" fill="white" />
            </>
          ) : (
            // Second icon - diamond with inner elements
            <>
              <polygon points="20,4 36,20 20,36 4,20" fill={colorPair[1]} stroke={colorPair[0]} strokeWidth="1" />
              <polygon points="20,10 28,20 20,30 12,20" fill={colorPair[0]} />
              <circle cx="20" cy="20" r="4" fill="white" />
            </>
          )}
        </svg>
      </div>
    )
  }

  return (
    <section id="education" className="py-24 md:py-32 px-6 md:px-12 border-t border-indigo-900/50" ref={ref}>
      <motion.div
        className="max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-16 tracking-tight text-white">
          Education
        </motion.h2>

        <div className="space-y-12">
          {educationEntries.map((entry, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="flex flex-col md:flex-row gap-6 md:gap-8 group p-6 rounded-lg bg-[rgba(20,20,40,0.7)] backdrop-blur-sm border border-indigo-900/50 hover:border-indigo-700/70 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
            >
              <div className="flex-shrink-0 flex items-start">
                <div className="w-16 h-16 rounded-full bg-indigo-900/30 flex items-center justify-center overflow-hidden border-2 border-indigo-700/50">
                  {createEducationIcon(index)}
                </div>
              </div>

              <div className="flex-grow">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                  <h3 className="text-xl font-semibold text-indigo-200 group-hover:text-white transition-colors">
                    {entry.institution}, {entry.location}
                  </h3>
                  <div className="flex items-center text-indigo-300 mt-1 md:mt-0">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span className="text-sm">{entry.period}</span>
                  </div>
                </div>

                <p className="text-indigo-300 mb-2">{entry.degree}</p>

                <div className="flex items-center text-indigo-400">
                  <Award className="h-4 w-4 mr-2" />
                  <span className="text-sm">{entry.gpa}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}
