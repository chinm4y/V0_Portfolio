"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function AboutMe() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section id="about" className="py-24 md:py-32 px-6 md:px-12 border-t border-indigo-900/30" ref={ref}>
      <motion.div
        className="max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <motion.h2
          variants={itemVariants}
          className="text-3xl md:text-4xl font-bold mb-12 tracking-tight text-white text-center md:text-left"
        >
          About Me
        </motion.h2>

        <motion.div
          variants={itemVariants}
          className="space-y-6 text-xl text-indigo-200 leading-relaxed text-center md:text-left"
        >
          <p>
            I'm Chinmay Deshpande — a product-focused data analyst and engineer passionate about solving real-world
            problems through data, automation, and thoughtful design. I thrive at the intersection of technology,
            analytics, and impact. I've worked on ADAS systems, BI dashboards, predictive models, and led data-driven
            decisions across domains.
          </p>

          <p>
            In 2021, I founded ASCK Solutions — a tech venture where we built an AI-powered order management system
            using Python Flask and Firebase. Leading this startup taught me to move fast, iterate often, and build with
            purpose.
          </p>

          <p>
            Outside the world of tech, I'm a state-level football (soccer) champion from India, having competed and won
            multiple tournaments. I'm also an avid hiker — exploring trails helps me recharge and find inspiration.
          </p>

          <p>
            I love working on side projects, geeking out over analytics dashboards, and learning new tools that push the
            boundaries of what's possible with data.
          </p>
        </motion.div>
      </motion.div>
    </section>
  )
}
