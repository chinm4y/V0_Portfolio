"use client"

import { useEffect, useRef } from "react"

type Star = {
  x: number
  y: number
  size: number
  opacity: number
  twinkleSpeed: number
  twinklePhase: number
}

type Planet = {
  x: number
  y: number
  size: number
  color: string
  orbitRadius: number
  orbitSpeed: number
  orbitAngle: number
  hasRing: boolean
  ringColor: string
  ringWidth: number
}

type Galaxy = {
  x: number
  y: number
  size: number
  rotation: number
  rotationSpeed: number
  speedX: number
  speedY: number
  color: string
  opacity: number
}

type ShootingStar = {
  startX: number
  startY: number
  length: number
  angle: number
  speed: number
  progress: number
  width: number
  active: boolean
  duration: number
}

export default function SpaceBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions to match window size and document height
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = document.documentElement.scrollHeight
    }

    window.addEventListener("resize", resizeCanvas)
    resizeCanvas()

    // Create stars
    const stars: Star[] = []
    const starCount = Math.min((window.innerWidth * window.innerHeight) / 500, 1000) // Responsive star count

    for (let i = 0; i < starCount; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5, // Stars of different sizes
        opacity: Math.random() * 0.5 + 0.5,
        twinkleSpeed: Math.random() * 0.02 + 0.01,
        twinklePhase: Math.random() * Math.PI * 2, // Random starting phase
      })
    }

    // Create planets
    const planets: Planet[] = []
    const planetCount = Math.min(window.innerWidth / 500, 4) // Limit number of planets

    const planetColors = [
      "#FF9D6F", // Mars-like
      "#A5BAFF", // Neptune-like
      "#FFD580", // Saturn-like
      "#FF6B6B", // Red planet
      "#72E7C3", // Uranus-like
      "#FFC3E7", // Pink planet
    ]

    const ringColors = [
      "#FFD700", // Gold
      "#C0C0C0", // Silver
      "#B87333", // Copper
      "#E6E6FA", // Lavender
    ]

    for (let i = 0; i < planetCount; i++) {
      planets.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 15 + 10,
        color: planetColors[Math.floor(Math.random() * planetColors.length)],
        orbitRadius: Math.random() * 100 + 50,
        orbitSpeed: Math.random() * 0.0005 + 0.0001,
        orbitAngle: Math.random() * Math.PI * 2,
        hasRing: Math.random() > 0.5,
        ringColor: ringColors[Math.floor(Math.random() * ringColors.length)],
        ringWidth: Math.random() * 5 + 3,
      })
    }

    // Create galaxies
    const galaxies: Galaxy[] = []
    const galaxyCount = Math.min(window.innerWidth / 300, 5) // Limit number of galaxies

    const galaxyColors = [
      "rgba(147, 112, 219, 0.2)", // Purple
      "rgba(70, 130, 180, 0.2)", // Steel Blue
      "rgba(100, 149, 237, 0.2)", // Cornflower Blue
      "rgba(123, 104, 238, 0.2)", // Medium Slate Blue
      "rgba(138, 43, 226, 0.2)", // Blue Violet
    ]

    for (let i = 0; i < galaxyCount; i++) {
      galaxies.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 100 + 50,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: Math.random() * 0.0005 - 0.00025,
        speedX: Math.random() * 0.1 - 0.05,
        speedY: Math.random() * 0.1 - 0.05,
        color: galaxyColors[Math.floor(Math.random() * galaxyColors.length)],
        opacity: Math.random() * 0.3 + 0.1,
      })
    }

    // Create shooting stars
    const shootingStars: ShootingStar[] = []
    const maxShootingStars = 5

    for (let i = 0; i < maxShootingStars; i++) {
      shootingStars.push({
        startX: 0,
        startY: 0,
        length: 0,
        angle: 0,
        speed: 0,
        progress: 0,
        width: 0,
        active: false,
        duration: 0,
      })
    }

    // Function to activate a shooting star
    const activateShootingStar = () => {
      for (let i = 0; i < shootingStars.length; i++) {
        if (!shootingStars[i].active) {
          const star = shootingStars[i]
          star.startX = Math.random() * canvas.width
          star.startY = Math.random() * (canvas.height / 3)
          star.length = Math.random() * 150 + 100
          star.angle = Math.PI / 4 + (Math.random() * Math.PI) / 4
          star.speed = Math.random() * 0.02 + 0.01
          star.progress = 0
          star.width = Math.random() * 3 + 1
          star.active = true
          star.duration = Math.random() * 100 + 100
          break
        }
      }
    }

    // Draw a star
    const drawStar = (star: Star, time: number) => {
      // Calculate twinkling effect
      const twinkle = Math.sin(time * star.twinkleSpeed + star.twinklePhase)
      const currentOpacity = star.opacity * (0.7 + 0.3 * twinkle)

      ctx.beginPath()
      ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
      ctx.fillStyle = `rgba(255, 255, 255, ${currentOpacity})`
      ctx.fill()

      // Add glow effect for larger stars
      if (star.size > 1.5) {
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size * 2, 0, Math.PI * 2)
        const gradient = ctx.createRadialGradient(star.x, star.y, 0, star.x, star.y, star.size * 2)
        gradient.addColorStop(0, `rgba(255, 255, 255, ${currentOpacity * 0.5})`)
        gradient.addColorStop(1, "rgba(255, 255, 255, 0)")
        ctx.fillStyle = gradient
        ctx.fill()
      }
    }

    // Draw a planet
    const drawPlanet = (planet: Planet, time: number) => {
      // Calculate orbit position
      const orbitX = planet.x + Math.cos(planet.orbitAngle) * planet.orbitRadius
      const orbitY = planet.y + Math.sin(planet.orbitAngle) * planet.orbitRadius

      // Draw planet
      ctx.beginPath()
      ctx.arc(orbitX, orbitY, planet.size, 0, Math.PI * 2)

      // Create gradient for planet
      const gradient = ctx.createRadialGradient(
        orbitX - planet.size / 3,
        orbitY - planet.size / 3,
        0,
        orbitX,
        orbitY,
        planet.size,
      )
      gradient.addColorStop(0, planet.color)
      gradient.addColorStop(1, `rgba(0, 0, 0, 0.5)`)
      ctx.fillStyle = gradient
      ctx.fill()

      // Draw ring if planet has one
      if (planet.hasRing) {
        ctx.beginPath()
        ctx.ellipse(orbitX, orbitY, planet.size * 1.8, planet.size * 0.5, Math.PI / 6, 0, Math.PI * 2)
        ctx.strokeStyle = planet.ringColor
        ctx.lineWidth = planet.ringWidth
        ctx.stroke()
      }

      // Add surface details
      const detailCount = Math.floor(planet.size / 3)
      ctx.fillStyle = `rgba(0, 0, 0, 0.2)`
      for (let i = 0; i < detailCount; i++) {
        const angle = Math.random() * Math.PI * 2
        const distance = Math.random() * (planet.size * 0.8)
        const detailSize = Math.random() * (planet.size / 5) + 1
        const detailX = orbitX + Math.cos(angle) * distance
        const detailY = orbitY + Math.sin(angle) * distance

        ctx.beginPath()
        ctx.arc(detailX, detailY, detailSize, 0, Math.PI * 2)
        ctx.fill()
      }

      // Update orbit angle for next frame
      planet.orbitAngle += planet.orbitSpeed
    }

    // Draw a galaxy
    const drawGalaxy = (galaxy: Galaxy) => {
      ctx.save()
      ctx.translate(galaxy.x, galaxy.y)
      ctx.rotate(galaxy.rotation)

      // Create spiral galaxy effect
      const arms = 3 + Math.floor(Math.random() * 3) // 3-5 arms
      const armWidth = (Math.PI * 2) / arms

      for (let a = 0; a < arms; a++) {
        const armAngle = a * armWidth

        for (let r = 0; r < galaxy.size; r += 2) {
          const angle = armAngle + (r / galaxy.size) * 5
          const x = Math.cos(angle) * (r / 2)
          const y = Math.sin(angle) * (r / 2)

          const distFromCenter = Math.sqrt(x * x + y * y)
          const opacity = Math.max(0, 1 - distFromCenter / galaxy.size) * galaxy.opacity

          if (Math.random() > 0.7) {
            ctx.beginPath()
            const starSize = Math.random() * 1.5 + 0.5
            ctx.arc(x, y, starSize, 0, Math.PI * 2)
            ctx.fillStyle = `rgba(255, 255, 255, ${opacity * 2})`
            ctx.fill()
          }

          if (Math.random() > 0.9) {
            ctx.beginPath()
            ctx.arc(x, y, Math.random() * 3 + 1, 0, Math.PI * 2)
            ctx.fillStyle = galaxy.color.replace("0.2", String(opacity))
            ctx.fill()
          }
        }
      }

      // Galaxy core
      const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, galaxy.size / 4)
      gradient.addColorStop(0, `rgba(255, 255, 255, ${galaxy.opacity * 1.5})`)
      gradient.addColorStop(1, "rgba(255, 255, 255, 0)")

      ctx.beginPath()
      ctx.arc(0, 0, galaxy.size / 4, 0, Math.PI * 2)
      ctx.fillStyle = gradient
      ctx.fill()

      ctx.restore()
    }

    // Draw a shooting star
    const drawShootingStar = (star: ShootingStar) => {
      if (!star.active) return

      // Calculate current position based on progress
      const currentX = star.startX + Math.cos(star.angle) * star.length * star.progress
      const currentY = star.startY + Math.sin(star.angle) * star.length * star.progress
      const tailX = currentX - Math.cos(star.angle) * star.length * 0.3
      const tailY = currentY - Math.sin(star.angle) * star.length * 0.3

      // Create gradient for the shooting star
      const gradient = ctx.createLinearGradient(currentX, currentY, tailX, tailY)
      gradient.addColorStop(0, "rgba(255, 255, 255, 0.9)")
      gradient.addColorStop(0.6, "rgba(200, 200, 255, 0.5)")
      gradient.addColorStop(1, "rgba(200, 200, 255, 0)")

      // Draw the shooting star
      ctx.beginPath()
      ctx.moveTo(currentX, currentY)
      ctx.lineTo(tailX, tailY)
      ctx.strokeStyle = gradient
      ctx.lineWidth = star.width
      ctx.lineCap = "round"
      ctx.stroke()

      // Add a small glow at the head
      ctx.beginPath()
      ctx.arc(currentX, currentY, star.width * 2, 0, Math.PI * 2)
      const headGradient = ctx.createRadialGradient(currentX, currentY, 0, currentX, currentY, star.width * 2)
      headGradient.addColorStop(0, "rgba(255, 255, 255, 0.8)")
      headGradient.addColorStop(1, "rgba(255, 255, 255, 0)")
      ctx.fillStyle = headGradient
      ctx.fill()

      // Update progress
      star.progress += star.speed
      if (star.progress >= 1) {
        star.active = false
      }
    }

    // Animation function
    const animate = () => {
      const time = Date.now() / 1000
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Create a dark space background with subtle gradient
      const bgGradient = ctx.createLinearGradient(0, 0, 0, canvas.height)
      bgGradient.addColorStop(0, "rgba(10, 10, 30, 1)")
      bgGradient.addColorStop(1, "rgba(20, 10, 40, 1)")
      ctx.fillStyle = bgGradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw stars
      stars.forEach((star) => {
        drawStar(star, time)
      })

      // Update and draw galaxies
      galaxies.forEach((galaxy) => {
        // Update position
        galaxy.x += galaxy.speedX
        galaxy.y += galaxy.speedY
        galaxy.rotation += galaxy.rotationSpeed

        // Wrap around edges
        if (galaxy.x > canvas.width + galaxy.size) {
          galaxy.x = -galaxy.size
        } else if (galaxy.x < -galaxy.size) {
          galaxy.x = canvas.width + galaxy.size
        }

        if (galaxy.y > canvas.height + galaxy.size) {
          galaxy.y = -galaxy.size
        } else if (galaxy.y < -galaxy.size) {
          galaxy.y = canvas.height + galaxy.size
        }

        // Draw galaxy
        drawGalaxy(galaxy)
      })

      // Update and draw planets
      planets.forEach((planet) => {
        drawPlanet(planet, time)
      })

      // Update and draw shooting stars
      shootingStars.forEach((star) => {
        drawShootingStar(star)
      })

      // Randomly activate new shooting stars
      if (Math.random() > 0.995) {
        activateShootingStar()
      }

      requestAnimationFrame(animate)
    }

    const animationId = requestAnimationFrame(animate)

    // Cleanup
    return () => {
      window.removeEventListener("resize", resizeCanvas)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-10"
      style={{ pointerEvents: "none" }}
      aria-hidden="true"
    />
  )
}
