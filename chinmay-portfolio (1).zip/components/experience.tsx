"use client"

import { useRef } from "react"
import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { Calendar, Building } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface ExperienceEntry {
  company: string
  role: string
  period: string
  contributions: string[]
}

export default function Experience() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })

  const experienceEntries: ExperienceEntry[] = [
    {
      company: "Ottometric",
      role: "Product Data Intern",
      period: "Jul 2024 – Dec 2024",
      contributions: [
        "Developed data pipelines for processing automotive safety metrics",
        "Created interactive dashboards for real-time monitoring",
        "Implemented machine learning models for predictive analysis",
      ],
    },
    {
      company: "Cognizant",
      role: "Data Analyst",
      period: "Oct 2022 – Mar 2023",
      contributions: [
        "Analyzed large datasets to identify business trends and opportunities",
        "Developed automated reporting systems for key stakeholders",
        "Collaborated with cross-functional teams to implement data-driven solutions",
      ],
    },
    {
      company: "Cognizant",
      role: "Data Analytics Intern",
      period: "Feb 2022 – Aug 2022",
      contributions: [
        "Assisted in data collection, cleaning, and analysis",
        "Created visualizations to communicate insights effectively",
        "Supported the development of predictive models",
      ],
    },
    {
      company: "ASCK Solutions",
      role: "Founder & Project Manager",
      period: "Jun 2021 – Jan 2022",
      contributions: [
        "Led a team developing custom data solutions for small businesses",
        "Managed client relationships and project timelines",
        "Designed and implemented database architectures",
      ],
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  // Create geometric icons for experience
  const createExperienceIcon = (index: number) => {
    const colors = [
      ["#EC4899", "#F9A8D4"], // pink
      ["#8B5CF6", "#C4B5FD"], // violet
      ["#3B82F6", "#93C5FD"], // blue
      ["#10B981", "#6EE7B7"], // emerald
    ]

    const colorPair = colors[index % colors.length]

    return (
      <div className="w-12 h-12 flex items-center justify-center">
        <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
          {index % 4 === 0 ? (
            // First icon - circle with inner elements
            <>
              <circle cx="20" cy="20" r="16" fill={colorPair[1]} />
              <circle cx="20" cy="20" r="10" fill={colorPair[0]} />
              <circle cx="20" cy="20" r="4" fill="white" />
            </>
          ) : index % 4 === 1 ? (
            // Second icon - square with inner elements
            <>
              <rect x="5" y="5" width="30" height="30" rx="4" fill={colorPair[1]} />
              <rect x="10" y="10" width="20" height="20" rx="2" fill={colorPair[0]} />
              <rect x="15" y="15" width="10" height="10" rx="1" fill="white" />
            </>
          ) : index % 4 === 2 ? (
            // Third icon - triangle with inner elements
            <>
              <polygon points="20,5 35,30 5,30" fill={colorPair[1]} />
              <polygon points="20,12 30,28 10,28" fill={colorPair[0]} />
              <polygon points="20,18 25,26 15,26" fill="white" />
            </>
          ) : (
            // Fourth icon - octagon with inner elements
            <>
              <polygon
                points="12,5 28,5 35,12 35,28 28,35 12,35 5,28 5,12"
                fill={colorPair[1]}
                stroke={colorPair[0]}
                strokeWidth="1"
              />
              <polygon points="15,10 25,10 30,15 30,25 25,30 15,30 10,25 10,15" fill={colorPair[0]} />
              <circle cx="20" cy="20" r="4" fill="white" />
            </>
          )}
        </svg>
      </div>
    )
  }

  return (
    <section id="experience" className="py-24 md:py-32 px-6 md:px-12 border-t border-purple-900/50" ref={ref}>
      <motion.div
        className="max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-16 tracking-tight text-white">
          Experience
        </motion.h2>

        <div className="space-y-8">
          {experienceEntries.map((entry, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="border border-purple-900/50 hover:border-purple-700/70 transition-colors hover:shadow-sm bg-[rgba(20,20,40,0.7)] backdrop-blur-sm shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-shrink-0 flex items-start">
                      <div className="w-12 h-12 rounded-full bg-purple-900/30 flex items-center justify-center">
                        {createExperienceIcon(index)}
                      </div>
                    </div>

                    <div className="flex-grow">
                      <div className="flex flex-col md:flex-row md:items-center justify-between mb-3">
                        <h3 className="text-xl font-semibold text-purple-200">{entry.role}</h3>
                        <div className="flex items-center text-purple-300 mt-1 md:mt-0">
                          <Calendar className="h-4 w-4 mr-2" />
                          <span className="text-sm">{entry.period}</span>
                        </div>
                      </div>

                      <div className="flex items-center text-purple-300 mb-4">
                        <Building className="h-4 w-4 mr-2" />
                        <span>{entry.company}</span>
                      </div>

                      <ul className="space-y-2 text-purple-300">
                        {entry.contributions.map((contribution, i) => (
                          <li key={i} className="flex items-start">
                            <span className="mr-2 mt-1.5">•</span>
                            <span>{contribution}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}
