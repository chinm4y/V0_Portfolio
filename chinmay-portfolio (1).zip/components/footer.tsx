export default function Footer() {
  return (
    <footer className="py-12 px-6 md:px-12 border-t border-indigo-900/30 bg-[rgba(20,20,40,0.7)] backdrop-blur-sm">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
        <p className="text-sm text-indigo-400 mb-4 md:mb-0">
          © {new Date().getFullYear()} Chinmay Deshpande. All rights reserved.
        </p>

        <div className="flex items-center space-x-6">
          <a href="#home" className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
            Back to top
          </a>
        </div>
      </div>
    </footer>
  )
}
