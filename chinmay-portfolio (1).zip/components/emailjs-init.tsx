"use client"

import { useEffect } from "react"

export default function EmailJSInit() {
  useEffect(() => {
    // Initialize EmailJS with your user ID
    if (typeof window !== "undefined" && window.emailjs) {
      window.emailjs.init("cuHZjaw6uINtQ3SPV") // Your EmailJS public key
    }
  }, [])

  return null
}
