"use client"

import { useEffect, useRef } from "react"

type Shape = {
  x: number
  y: number
  size: number
  rotation: number
  rotationSpeed: number
  speedX: number
  speedY: number
  type: "circle" | "square" | "triangle"
  color: string
  opacity: number
}

export default function GeometricBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions to match window size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = document.documentElement.scrollHeight
    }

    window.addEventListener("resize", resizeCanvas)
    resizeCanvas()

    // Create shapes
    const shapes: Shape[] = []
    const shapeCount = Math.min(window.innerWidth / 15, 80) // Responsive shape count

    const colors = [
      "rgba(230, 230, 250, 0.4)", // lavender
      "rgba(209, 231, 221, 0.4)", // mint
      "rgba(255, 218, 185, 0.4)", // peach
      "rgba(204, 236, 255, 0.4)", // sky
      "rgba(216, 191, 216, 0.4)", // purple
      "rgba(175, 238, 238, 0.4)", // teal
    ]

    const shapeTypes: Array<"circle" | "square" | "triangle"> = ["circle", "square", "triangle"]

    for (let i = 0; i < shapeCount; i++) {
      shapes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 20 + 10,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: Math.random() * 0.002 - 0.001,
        speedX: Math.random() * 0.3 - 0.15,
        speedY: Math.random() * 0.3 - 0.15,
        type: shapeTypes[Math.floor(Math.random() * shapeTypes.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
        opacity: Math.random() * 0.3 + 0.1,
      })
    }

    // Draw a shape based on its type
    const drawShape = (shape: Shape) => {
      ctx.save()
      ctx.translate(shape.x, shape.y)
      ctx.rotate(shape.rotation)
      ctx.fillStyle = shape.color

      switch (shape.type) {
        case "circle":
          ctx.beginPath()
          ctx.arc(0, 0, shape.size, 0, Math.PI * 2)
          ctx.fill()
          break

        case "square":
          ctx.fillRect(-shape.size / 2, -shape.size / 2, shape.size, shape.size)
          break

        case "triangle":
          ctx.beginPath()
          ctx.moveTo(0, -shape.size / 2)
          ctx.lineTo(shape.size / 2, shape.size / 2)
          ctx.lineTo(-shape.size / 2, shape.size / 2)
          ctx.closePath()
          ctx.fill()
          break
      }

      ctx.restore()
    }

    // Animation function
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw shapes
      shapes.forEach((shape) => {
        // Update position
        shape.x += shape.speedX
        shape.y += shape.speedY
        shape.rotation += shape.rotationSpeed

        // Bounce off edges with some padding
        const padding = shape.size * 2

        if (shape.x > canvas.width + padding) {
          shape.x = -padding
        } else if (shape.x < -padding) {
          shape.x = canvas.width + padding
        }

        if (shape.y > canvas.height + padding) {
          shape.y = -padding
        } else if (shape.y < -padding) {
          shape.y = canvas.height + padding
        }

        // Draw shape
        drawShape(shape)
      })

      requestAnimationFrame(animate)
    }

    const animationId = requestAnimationFrame(animate)

    // Cleanup
    return () => {
      window.removeEventListener("resize", resizeCanvas)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-10 opacity-60"
      style={{ pointerEvents: "none" }}
      aria-hidden="true"
    />
  )
}
