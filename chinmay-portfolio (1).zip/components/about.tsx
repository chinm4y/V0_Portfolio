"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function About() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.3 })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8 } },
  }

  return (
    <section id="about" className="py-24 md:py-32 px-6 md:px-12" ref={ref}>
      <motion.div
        className="max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-light mb-12 tracking-tight">
          About
        </motion.h2>

        <div className="grid md:grid-cols-2 gap-12 md:gap-24">
          <motion.div variants={itemVariants} className="space-y-6">
            <p className="text-lg text-gray-300">
              I'm a data analyst and engineer with a focus on creating product-driven solutions. With experience at
              companies like Ottometric and Cognizant, I specialize in transforming complex data into actionable
              insights.
            </p>
            <p className="text-lg text-gray-300">
              My approach combines technical expertise with a deep understanding of business needs, allowing me to build
              data systems that drive real-world impact.
            </p>
          </motion.div>

          <motion.div variants={itemVariants} className="space-y-8">
            <div>
              <h3 className="text-xl font-medium mb-4">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {[
                  "Data Analysis",
                  "Python",
                  "SQL",
                  "Machine Learning",
                  "Data Visualization",
                  "ETL Pipelines",
                  "Product Analytics",
                  "Dashboard Design",
                ].map((skill) => (
                  <span key={skill} className="px-3 py-1 bg-white/5 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xl font-medium mb-4">Education</h3>
              <div className="space-y-2">
                <p className="text-gray-300">MS in Information Systems — Northeastern University</p>
                <p className="text-gray-300">BE in Computer Engineering — Pune University</p>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  )
}
