"use client"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { Github, ExternalLink } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"

interface Project {
  id: number
  title: string
  repoName: string
  description: string
  url: string
  icon: JSX.Element
}

export default function Projects() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.1 })
  const [hoveredId, setHoveredId] = useState<number | null>(null)

  // Create geometric icons for each project
  const createGeometricIcon = (id: number) => {
    const colors = [
      ["#6366F1", "#A5B4FC"], // indigo
      ["#8B5CF6", "#C4B5FD"], // violet
      ["#EC4899", "#F9A8D4"], // pink
      ["#10B981", "#6EE7B7"], // emerald
      ["#3B82F6", "#93C5FD"], // blue
      ["#F59E0B", "#FCD34D"], // amber
    ]

    const colorPair = colors[id % colors.length]

    // Different geometric patterns for each project
    switch (id % 6) {
      case 0:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <circle cx="20" cy="20" r="16" fill={colorPair[1]} />
              <circle cx="20" cy="20" r="10" fill={colorPair[0]} />
              <circle cx="20" cy="20" r="4" fill="white" />
            </svg>
          </div>
        )
      case 1:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <rect x="5" y="5" width="30" height="30" fill={colorPair[1]} />
              <rect x="10" y="10" width="20" height="20" fill={colorPair[0]} />
              <rect x="15" y="15" width="10" height="10" fill="white" />
            </svg>
          </div>
        )
      case 2:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <polygon points="20,5 35,30 5,30" fill={colorPair[1]} />
              <polygon points="20,12 30,28 10,28" fill={colorPair[0]} />
              <polygon points="20,18 25,26 15,26" fill="white" />
            </svg>
          </div>
        )
      case 3:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <rect x="5" y="5" width="30" height="30" rx="15" fill={colorPair[1]} />
              <rect x="10" y="10" width="20" height="20" rx="10" fill={colorPair[0]} />
              <rect x="15" y="15" width="10" height="10" rx="5" fill="white" />
            </svg>
          </div>
        )
      case 4:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <polygon points="5,20 20,5 35,20 20,35" fill={colorPair[1]} />
              <polygon points="10,20 20,10 30,20 20,30" fill={colorPair[0]} />
              <polygon points="15,20 20,15 25,20 20,25" fill="white" />
            </svg>
          </div>
        )
      case 5:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <circle cx="20" cy="20" r="15" fill={colorPair[1]} />
              <polygon points="20,5 27,15 35,15 30,25 35,35 20,30 5,35 10,25 5,15 13,15" fill={colorPair[0]} />
              <circle cx="20" cy="20" r="5" fill="white" />
            </svg>
          </div>
        )
      default:
        return (
          <div className="w-12 h-12 flex items-center justify-center">
            <svg viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
              <circle cx="20" cy="20" r="15" fill={colorPair[0]} />
            </svg>
          </div>
        )
    }
  }

  const projects: Project[] = [
    {
      id: 1,
      title: "Premier League Predictive Analysis",
      repoName: "Premier-League-Predictive-Analysis",
      description: "View project on GitHub",
      url: "https://github.com/chinm4y/Premier-League-Predictive-Analysis",
      icon: createGeometricIcon(0),
    },
    {
      id: 2,
      title: "Seattle Pet Licenses Analysis",
      repoName: "SeattlePetLicenses-Analysis",
      description: "View project on GitHub",
      url: "https://github.com/chinm4y/SeattlePetLicenses-Analysis",
      icon: createGeometricIcon(1),
    },
    {
      id: 3,
      title: "Digital Education Platform",
      repoName: "DigitalEducationPlatform",
      description: "View project on GitHub",
      url: "https://github.com/chinm4y/DigitalEducationPlatform",
      icon: createGeometricIcon(2),
    },
    {
      id: 4,
      title: "Food Inspections Data Analysis",
      repoName: "Food-Inspections-Data-Analysis-Dallas-Chicago",
      description: "View project on GitHub",
      url: "https://github.com/chinm4y/Food-Inspections-Data-Analysis-Dallas-Chicago",
      icon: createGeometricIcon(3),
    },
    {
      id: 5,
      title: "Crime Predictor",
      repoName: "Crime-Predictor",
      description: "View project on GitHub",
      url: "https://github.com/chinm4y/Crime-Predictor",
      icon: createGeometricIcon(4),
    },
    {
      id: 6,
      title: "Words and Sips",
      repoName: "wordsandsips",
      description: "View project on GitHub",
      url: "https://github.com/chinm4y/wordsandsips",
      icon: createGeometricIcon(5),
    },
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  }

  return (
    <section id="projects" className="py-24 md:py-32 px-6 md:px-12 border-t border-indigo-900/30" ref={ref}>
      <motion.div
        className="max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold mb-16 tracking-tight text-white">
          Projects
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <motion.div
              key={project.id}
              variants={itemVariants}
              onMouseEnter={() => setHoveredId(project.id)}
              onMouseLeave={() => setHoveredId(null)}
              className="group"
            >
              <a
                href={project.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block h-full"
                aria-label={`View ${project.repoName} on GitHub`}
              >
                <Card
                  className="overflow-hidden h-full transition-all duration-300 hover:shadow-lg border border-indigo-900 bg-[rgba(20,20,40,0.7)] backdrop-blur-sm shadow-[0_4px_20px_rgba(0,0,0,0.3)]"
                  style={{
                    transform: hoveredId === project.id ? "scale(1.03)" : "scale(1)",
                  }}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="flex-shrink-0 mt-1 bg-[rgba(30,30,60,0.5)] p-2 rounded-lg">{project.icon}</div>
                      <div className="flex-grow">
                        <h3 className="text-xl font-semibold text-indigo-200 group-hover:text-white transition-colors mb-1">
                          {project.repoName}
                        </h3>
                        <p className="text-indigo-300 group-hover:text-indigo-200 transition-colors text-sm">
                          {project.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="px-6 pb-6 pt-0 flex justify-between items-center">
                    <div className="flex items-center text-indigo-400 group-hover:text-indigo-300 transition-colors">
                      <Github className="h-4 w-4 mr-2" />
                      <span className="text-sm">GitHub</span>
                    </div>
                    <ExternalLink className="h-4 w-4 text-indigo-400 group-hover:text-indigo-300 transition-colors opacity-0 group-hover:opacity-100 transform translate-x-0 group-hover:translate-x-1 transition-all" />
                  </CardFooter>
                </Card>
              </a>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}
